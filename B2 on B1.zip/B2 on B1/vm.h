#ifndef VM_H
#define VM_H

#include "vm_menu.h"

#define INPUT_LEN 1

#endif
